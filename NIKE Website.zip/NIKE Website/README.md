# Project 1 - Brand Page

<img width="1158" alt="image" src="https://user-images.githubusercontent.com/50476777/236659089-c7d1675e-4b81-4dcc-8e09-bd09bb444917.png">


Design - https://www.figma.com/file/rephrU2FVgN8MFz6XhnP51/Learn-React-with-10-Projects?type=design&node-id=0-1&t=orp3GQEAXhmtQcgG-0



